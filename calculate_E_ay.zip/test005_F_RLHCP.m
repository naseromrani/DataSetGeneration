clc
clear
close all

%%%%%% ---> parameters

eta_0 = 120 * pi;
theta = linspace(-90, 90, 500) * pi / 180;
phi = 0;

pol_flag = 'r';     % Polarization State
bc_flag = 't';      % Polarization State


main_data = [];
for temp=0.1:0.1:1.1
    for M=0.1:0.1:1 
        for i=0:0.1:1
            for j=0:0.1:1
                for k=0:0.1:1
                    for q=0:0.1:1
                        sum = i+j+k+q;
                        if sum~= 0 & sum<=1
                            modulation_coeffs=[i,j,k,q];
                            X_op = temp * eta_0;         % Hologram Specs 
                            initialize_structure;
                            F_RHCP_log, F_LHCP_log = calculate_FRLCP_log(freq, theta_0, phi_0, pol_flag, psi_slant, X_op, M, x_min, x_max, y_min, y_max, epsilon_r, h, tc, modulation_coeffs);
                            data = [temp, M, i, j, k, q, F_RHCP_log, F_LHCP_log];
                            main_data = [main_data; data];
                        end
                    end
                end
            end
        end
    end
end

filename = "main_data"
save(filename,'main_data')
