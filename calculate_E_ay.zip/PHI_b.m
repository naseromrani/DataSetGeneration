function phi_phi = PHI_b(rho, phi, tc)

phi_phi = tc * phi;

end