function phi_rho = PHI_a(rho, phi, tc)

phi_rho = tc * phi;

end